/*
    This date string is hereby put into the public domain.
    Copyrighting this is crazy. It's just a date string
    and is modified from time to time.
*/

#define DW_VERSION_DATE_STR " 2019-05-29 08:43:30-07:00  "
