/* Automatically generated, do not edit. */
/* Generated sourcedate  2019-05-29 08:43:30-07:00   */

/* BEGIN FILE */

/* define DWARF_PRINT_PREFIX before this
   point if you wish to.  */
#ifndef DWARF_PRINT_PREFIX
#define DWARF_PRINT_PREFIX dwarf_
#endif
#define dw_glue(x,y) x##y
#define dw_glue2(x,y) dw_glue(x,y)
#define DWPREFIX(x) dw_glue2(DWARF_PRINT_PREFIX,x)
int DWPREFIX(get_TAG_name) (unsigned int, const char **);
int DWPREFIX(get_children_name) (unsigned int, const char **);
int DWPREFIX(get_FORM_name) (unsigned int, const char **);
int DWPREFIX(get_AT_name) (unsigned int, const char **);
int DWPREFIX(get_OP_name) (unsigned int, const char **);
int DWPREFIX(get_ATE_name) (unsigned int, const char **);
int DWPREFIX(get_DEFAULTED_name) (unsigned int, const char **);
int DWPREFIX(get_IDX_name) (unsigned int, const char **);
int DWPREFIX(get_LLEX_name) (unsigned int, const char **);
int DWPREFIX(get_LLE_name) (unsigned int, const char **);
int DWPREFIX(get_RLE_name) (unsigned int, const char **);
int DWPREFIX(get_UT_name) (unsigned int, const char **);
int DWPREFIX(get_SECT_name) (unsigned int, const char **);
int DWPREFIX(get_DS_name) (unsigned int, const char **);
int DWPREFIX(get_END_name) (unsigned int, const char **);
int DWPREFIX(get_ATCF_name) (unsigned int, const char **);
int DWPREFIX(get_ACCESS_name) (unsigned int, const char **);
int DWPREFIX(get_VIS_name) (unsigned int, const char **);
int DWPREFIX(get_VIRTUALITY_name) (unsigned int, const char **);
int DWPREFIX(get_LANG_name) (unsigned int, const char **);
int DWPREFIX(get_ID_name) (unsigned int, const char **);
int DWPREFIX(get_CC_name) (unsigned int, const char **);
int DWPREFIX(get_INL_name) (unsigned int, const char **);
int DWPREFIX(get_ORD_name) (unsigned int, const char **);
int DWPREFIX(get_DSC_name) (unsigned int, const char **);
int DWPREFIX(get_LNCT_name) (unsigned int, const char **);
int DWPREFIX(get_LNS_name) (unsigned int, const char **);
int DWPREFIX(get_LNE_name) (unsigned int, const char **);
int DWPREFIX(get_ISA_name) (unsigned int, const char **);
int DWPREFIX(get_MACRO_name) (unsigned int, const char **);
int DWPREFIX(get_MACINFO_name) (unsigned int, const char **);
int DWPREFIX(get_CFA_name) (unsigned int, const char **);
int DWPREFIX(get_EH_name) (unsigned int, const char **);
int DWPREFIX(get_FRAME_name) (unsigned int, const char **);
int DWPREFIX(get_CHILDREN_name) (unsigned int, const char **);
int DWPREFIX(get_ADDR_name) (unsigned int, const char **);

/* END FILE */
