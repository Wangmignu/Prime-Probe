/* Generated code, do not edit. */
/* Generated sourcedate  2019-05-29 08:43:30-07:00   */

/* BEGIN FILE */

#define TAG_TREE_EXT_COLUMN_COUNT 5

#define TAG_TREE_EXT_ROW_COUNT 9

/* Common extensions */
static unsigned int tag_tree_combination_ext_table[TAG_TREE_EXT_ROW_COUNT][TAG_TREE_EXT_COLUMN_COUNT] = {
/* 0x13 - DW_TAG_structure_type                */
    { 0x00000013,0x00000034,0x00004106,0x00004107,0x00004108,},
/* 0x02 - DW_TAG_class_type                    */
    { 0x00000002,0x00000034,0x00004106,0x00004107,0x00004108,},
/* 0x0b - DW_TAG_lexical_block                 */
    { 0x0000000b,0x00004109,0x00000000,0x00000000,0x00000000,},
/* 0x2e - DW_TAG_subprogram                    */
    { 0x0000002e,0x00004109,0x00004106,0x00004107,0x00004108,},
/* 0x17 - DW_TAG_union_type                    */
    { 0x00000017,0x00004106,0x00004107,0x00004108,0x00000000,},
/* 0x1d - DW_TAG_inlined_subroutine            */
    { 0x0000001d,0x00004109,0x00000000,0x00000000,0x00000000,},
/* 0x4109 - DW_TAG_GNU_call_site                 */
    { 0x00004109,0x0000410a,0x00000000,0x00000000,0x00000000,},
/* 0x4107 - DW_TAG_GNU_template_parameter_pack   */
    { 0x00004107,0x0000002f,0x00000030,0x00004106,0x00000000,},
/* 0x4108 - DW_TAG_GNU_formal_parameter_pack     */
    { 0x00004108,0x00000005,0x00000000,0x00000000,0x00000000,},
};

/* END FILE */
